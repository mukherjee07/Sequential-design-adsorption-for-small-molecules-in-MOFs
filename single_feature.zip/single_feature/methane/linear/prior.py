'''
Author: Krish-the evergreen-mukherjee
Advisor: Dr. Yamil Colon, University of Notre Dame
Objective: The objective of this code is to create a Prior dataset for active updating for later stages. We are going to employ Latin hypercube sampling (LHS) to achieve this.
'''

#importing libraries
import numpy as np
import pandas as pd
import math

#importing the latin-hypercube sampling multi-dimensional uniformity 
import lhsmdu 

#importing operating system library
import os

#defining the variable space for latin hypercube sampling
p_min = 1.0e-1 #max and min pressure
p_max = 3.0e+7
#Y = np.log10(p_max)
#X = np.log10(p_min)

#Y = p_max
#X = p_min

#B = X/(abs(X)+abs(Y))
#Filename for assigning charges
#print(B,X,Y)

#Creating a prior data file for printing sample datapoints
FILENAME='Prior.csv'
os.system("rm -f "+str(FILENAME))
os.system("touch "+str(FILENAME))
os.system("echo Press >> "+str(FILENAME))

'''
X_test = np.atleast_2d(np.linspace(0.1,30000000,50)).flatten().reshape(-1,1)

#FOR generating Prior dataset for comparision 
for i in range(len(X_test)):
	os.system("echo "+str(X_test[i])+" >> Prior.csv")
'''
#Entering number of features and samples required
N_parameter = 1 #this would be fixed throughout
N_samp = 4

#Sampling 20 samples for the 44 variables (22 in 1 ring, 44 in 2 rings)
k = lhsmdu.sample(N_parameter, N_samp) # Latin Hypercube Sampling with multi-dimensional uniformity

#converting the k which is an np 2D matrix into np array
k = np.squeeze(np.asarray(k))
#print(type(k))

D = (k*(p_max - p_min))+p_min
#D = ((abs(X)+abs(Y))*(k+B))
print(type(D))
#S = np.size(D)
for i in range(len(D)):
	os.system("echo "+str(D[i])+">> "+str(FILENAME))
	#print(D[i])


