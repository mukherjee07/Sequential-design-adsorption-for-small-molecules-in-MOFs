#!/usr/bin/env python
# coding: utf-8

#importing important libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import math

#importing the ML libraries
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, RationalQuadratic, WhiteKernel 
from sklearn.gaussian_process.kernels import ConstantKernel as C

#Reading the dataset
df = pd.read_csv('prior_Sample.csv',delimiter=',')
df2 = pd.read_csv('complete.csv',delimiter=',')
#print(df.head())

#defining the pressure limit
p1=1e-6
p2=300

#switching to limit variable
l1 = np.log10(p1)
l2 = np.log10(p2)

#creating lin space in log space — linearly 
X_test = np.atleast_2d(np.linspace(l1,l2,50)).flatten().reshape(-1,1)

#X_test = 10**X_test
#FOR generating Prior dataset for comparision 
'''
for i in range(len(X_test)):
	os.system("echo "+str(X_test[i])+" >> Prior.csv")

'''
#Reading the data
x = df.iloc[:,0].values
y = df.iloc[:,1].values
#Taking the error data as well
e = df.iloc[:,2].values

#from complete-original dataset
x2 = df2.iloc[:,0].values
y2 = df2.iloc[:,1].values

#Replacing y if some y value in zero
for i in range(len(y)):
	if (y[i] == 0):
		y[i] = 0.0001

#For y2
for i in range(len(y2)):
	if (y2[i] == 0):
		y2[i] = 0.0001

#Transforming 1D arrays to 2D
x = np.atleast_2d(x).flatten().reshape(-1,1)
y = np.atleast_2d(y).flatten().reshape(-1,1)

#Storing the value of x and y in these two variables
x_true = x
y_actual = y

#converting P to bars
x = x/(1.0e5)
#Taking logbase 10 of the input vector
x = np.log10(x)
y = np.log10(y)

#Extracting the mean and std. dev for X_test
x_m = np.mean(X_test)
x_std = np.std(X_test,ddof=1)

#Standardising x and y in log-space
x_s = (x - x_m)/x_std

#Standardising X_test in log-space
X_test = (X_test - x_m)/x_std

#print(x_s,y)
#Building the GP regresson 
# Instantiate a Gaussian Process model
#kernel = C(1.0, (1e-3, 1e3)) * RationalQuadratic(10, (1e-2, 1e2))
kernel = RationalQuadratic(length_scale=500, alpha=0.5,length_scale_bounds=(1e-8,1e8),alpha_bounds=(1e-8,1e8))
gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=50, normalize_y=True)

#Fitting our normalized data to the GP model
gp.fit(x_s,y)

#print(X_test)
# Make the prediction on the test data (ask for MSE as well)
y_pred, sigma = gp.predict(X_test, return_std=True)
#print(y_pred,sigma)
rel_error = np.zeros(len(sigma))

#finding the relative error—
for i in range(len(sigma)):
    rel_error[i] = abs(sigma[i]/abs(y_pred[i]))

#define the limit for uncertainty
lim = 0.02
Max = np.amax(rel_error)
index = np.argmax(rel_error)

#transforming the index to original pressure point
X_test = (X_test*x_std) + x_m
X_test = 10**(X_test)
X_test = 1e5*(X_test)
#print(X_test,10**(y_pred),rel_error)

y_pred = 10**y_pred
print(np.shape(X_test),np.shape(y_actual))

rel_error = 100*(rel_error)

#defining relative root mean square error
#defining relative true error
rel_t = np.zeros(len(X_test))
for i in range(len(rel_t)):
	rel_t[i] = ((y_pred[i] - y2[i])/y2[i])
	#print(rel_t[i])

#Finding relative root mean square error
rrmse = 0
for i in range(len(rel_error)):
	rrmse = rrmse + (((y_pred[i] - y2[i])**2)/y2[i]**2)
	X= (((y_pred[i] - y2[i])**2)/y2[i]**2)
	#print(X_test[i],p2[i],t2[i],y_pred[i],y2[i])
rrmse = 100*(np.sqrt(rrmse))/len(rel_error)
### This piece of code block below is simply for testing purposes, i.e. comparing the test set and grouth truth results
'''
#Converting X_test to real values pf pressure and temperature for comparing them in future
X_test[:,0] = (X_test[:,0]*p_std) + p_m
X_test[:,0] = 10**(X_test[:,0])
#X_test[:,0] = 1e5*(X_test[:,0])
X_test[:,1] = (X_test[:,1]*t_std) + t_m
X_test[:,1] = 10**(X_test[:,1])

# Printing the variables for comparision
for i in range(len(y2)):
	print('Real Pressure and Temperature, Test Pressure and Temperature, then predicted and actual uptake of methane : ',p2[i],t2[i],X_test[i],y_pred[i],y2[i])
'''
#converting the true rel error in percentage
rel_t = 100*(abs(rel_t))

#finding the mean of relative error
rel_m = np.amax(rel_error)

#printing mean of rel error and rrmse for each iteration in a separate mean.csv file
os.system("echo -n "+str(rel_m)+","+str(rrmse)+" >> mean.csv")

##printing rel error and true rel. error in a error file
for i in range(len(rel_error)):
	#rounding off the error to 3 digits after decimals
	rel_t[i] = round(rel_t[i],3)
	rel_error[i] = round(rel_error[i],3)
	#printing them in the .csv files for error
	os.system("echo -n "+str(rel_error[i])+" >> rel.csv")
	os.system("echo -n "+str(rel_t[i])+" >> rel_true.csv")
	if ( i != (len(rel_error) - 1)): 
		os.system("echo -n "+","+" >> rel.csv")
		os.system("echo -n "+","+" >> rel_true.csv")
